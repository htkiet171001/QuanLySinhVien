﻿using DevComponents.DotNetBar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Day la form giao dien chinh//
namespace QuanLySV_FiveTeam
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }
        //Code de dua form con hien thi tren form chinh(form main)//
        private Form currentFormChinh;
        private void OpenFormChinh(Form formChinh)
        {
            if (currentFormChinh != null)//Kiem tra form duoc khoi tao//
            {
                currentFormChinh.Close();
            }
            currentFormChinh = formChinh;
            formChinh.TopLevel = false;
            formChinh.Dock = DockStyle.Fill;//Phong to va bao tron panel chua form con
            panel3.Controls.Add(formChinh);
            panel3.Tag = formChinh;//Truyen tai du lieu vao panel
            formChinh.BringToFront();//Dua du lieu len truoc
            formChinh.Show();//show du lieu len form cha
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFormChinh(new QuanLyHoSoSV());//Dua form quan ly ho so len form chinh qua button Quan ly ho so sv
            labell.Text = button2.Text;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFormChinh(new QuanLyDSLop());//tuong tu nhu vay,dua form QuanLyDSLop hien thi len form cha qua button Quan ly ds lop
            labell.Text = button5.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (currentFormChinh != null)//Kiem tra form da khoi tao va dong no lai de quay lai trang chu
            {
                currentFormChinh.Close();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();//button thoat khoi ct
        }
    }
}
