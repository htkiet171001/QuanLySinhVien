﻿namespace Lop
{
    internal class Lop
    {
        private long stt;
        private string khoahoc;
        private string lopp;
        private string gvcn;
        private string khoa;
        private string soluong;
        public Lop() { }
        public Lop(long stt, string lopp, string khoahoc, string gvcn, string khoa, string soluong)
        {
            this.Stt = Stt;
            this.Lopp = lopp;
            this.Khoahoc = khoahoc;
            this.Gvcn = gvcn;
            this.Khoa = khoa;
            this.Soluong = soluong;
        }

        public string Khoahoc { get => khoahoc; set => khoahoc = value; }
        public string Gvcn { get => gvcn; set => gvcn = value; }
        public string Khoa { get => khoa; set => khoa = value; }
        public string Soluong { get => soluong; set => soluong = value; }
        public long Stt { get => stt; set => stt = value; }
        public string Lopp { get => lopp; set => lopp = value; }
    }
}