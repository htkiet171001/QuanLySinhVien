﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySV_FiveTeam.User
{
    class Usercf
    {
        private long id;
        private string username;
        private string pass;

        public Usercf() { }

        public Usercf(long id, string username, string pass, string question)
        {
            this.id = id;
            this.username = username;
            this.pass = pass;
        }

        public long Id { get => id; set => id = value; }
        public string Username { get => username; set => username = value; }
        public string Pass { get => pass; set => pass = value; }
    }
}
