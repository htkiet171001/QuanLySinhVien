﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    public partial class QuanLyDSLop : Form
    {
        DataTable dataTable = new DataTable();
        public QuanLyDSLop()
        {
            
            InitializeComponent();
        }
        DSLop ds;
        int indx;
        public void DocFile(string path)//docfile du lieu
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    foreach (Lop.Lop item in DSLop.ListDSL)
                    {
                        sw.WriteLine(string.Format("{0},{1},{2},{3},{4},{5}",//Xuat doi tuong ra man hinh 
                            item.Stt, item.Khoahoc, item.Lopp, item.Gvcn, item.Khoa, item.Soluong));
                    }
                }
            }
        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void QuanLyDSLop_Load(object sender, EventArgs e)
        {
            
            ds = new DSLop();
            Showw();
        }
        private void Showw()
        {
            ds.GetLop(DSLop.pathfile);
            BindingSource bin = new BindingSource();//Su dung BindingSource đe dieu khien danh sach
            bin.DataSource = DSLop.ListDSL;
            dataGridView1.DataSource = bin;
        }

        Lop.Lop lop;
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string searchValue = btntim.Text;
            int rowIndex = 1;  //this one is depending on the position of cell or column
                               //string first_row_data=dataGridView1.Rows[0].Cells[0].Value.ToString() ;

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                bool valueResulet = true;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[rowIndex].Value.ToString().Equals(searchValue))
                    {
                        rowIndex = row.Index;
                        dataGridView1.Rows[rowIndex].Selected = true;
                        rowIndex++;
                        valueResulet = false;
                    }
                }
                if (valueResulet != false)
                {
                    MessageBox.Show("Không tìm thấy  " + btntim.Text, "Not Found");
                    return;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }

        private void btntim_TextChanged(object sender, EventArgs e)
        {
            //(dataGridView1.DataSource as DataTable).DefaultView.RowFilter =
            //    String.Format("Lớp like '%" + btntim.Text + "%'");
           

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            indx = e.RowIndex;
            if (e.RowIndex >= 0)
            {
                //Lưu lại dòng dữ liệu vừa kích chọn
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                //Đưa dữ liệu vào textbox
                txtStt.Text = row.Cells[0].Value.ToString();
                txtKhoahoc.Text = row.Cells[1].Value.ToString();
                txtLopp.Text = row.Cells[2].Value.ToString();
                txtGvcn.Text = row.Cells[3].Value.ToString();
                txtKhoa.Text = row.Cells[4].Value.ToString();
                txtSoluong.Text = row.Cells[5].Value.ToString();
            }
            }

            private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.RowCount > 0)//Kiểm tra dataGridView có dữ liệu hay không
            {
                lop = new Lop.Lop()
                {
                    //Truy xuất giá trị các cột trong BindingSource
                    Stt = Convert.ToInt64(dataGridView1.CurrentRow.Cells["col_Stt"].Value.ToString()),
                    Khoahoc = dataGridView1.CurrentRow.Cells["col_Khoahoc"].Value.ToString(),
                    Lopp = dataGridView1.CurrentRow.Cells["col_Lop"].Value.ToString(),
                    Gvcn = dataGridView1.CurrentRow.Cells["col_Gvcn"].Value.ToString(),
                    Khoa = dataGridView1.CurrentRow.Cells["col_Khoa"].Value.ToString(),
                    Soluong = dataGridView1.CurrentRow.Cells["col_Soluong"].Value.ToString(),
                };
                txtStt.Text =dataGridView1.CurrentRow.Cells["col_Stt"].Value.ToString();
                txtKhoahoc.Text = dataGridView1.CurrentRow.Cells["col_Khoahoc"].Value.ToString();
                txtLopp.Text = dataGridView1.CurrentRow.Cells["col_Lop"].Value.ToString();
                txtGvcn.Text = dataGridView1.CurrentRow.Cells["col_Gvcn"].Value.ToString();
                txtKhoa.Text = dataGridView1.CurrentRow.Cells["col_Khoa"].Value.ToString();
                txtSoluong.Text = dataGridView1.CurrentRow.Cells["col_Soluong"].Value.ToString();
                
            }
        }

        private void btnSua_Click(object sender, EventArgs e)///Button "sua"
        {
            DataGridViewRow newdata1 = dataGridView1.Rows[indx];
            newdata1.Cells[0].Value = txtStt.Text;
            newdata1.Cells[1].Value = txtKhoahoc.Text;
            newdata1.Cells[2].Value = txtLopp.Text;
            newdata1.Cells[3].Value = txtGvcn.Text;
            newdata1.Cells[4].Value = txtKhoa.Text;
            newdata1.Cells[5].Value = txtSoluong.Text;
            MessageBox.Show("Sửa và Update Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoa_Click(object sender, EventArgs e)//button "xoa"
        {
            indx = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(indx);
            MessageBox.Show("Xóa Sinh Viên Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnThem_Click(object sender, EventArgs e)//button "Them"
        {
            if (!string.IsNullOrEmpty(txtLopp.Text))//Kiem tra thuoc tinh lop
            {
                Lop.Lop lop = new Lop.Lop();
                long max = DSLop.ListDSL[0].Stt;
                for (int i = 0; i < DSLop.ListDSL.Count; i++)
                {
                    if (max < DSLop.ListDSL[i].Stt)
                    {
                        max = DSLop.ListDSL[i].Stt;
                    }
                }
                lop.Stt = Convert.ToInt64(txtStt.Text);
                lop.Khoahoc = txtKhoahoc.Text;
                lop.Lopp = txtLopp.Text;
                lop.Gvcn = txtGvcn.Text;
                lop.Khoa = txtKhoa.Text;
                lop.Soluong = txtSoluong.Text;
                DSLop.ListDSL.Add(lop);
                DocFile(DSLop.pathfile);
                Showw();
                MessageBox.Show("Thêm Sinh Viên Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                MessageBox.Show("Thiếu Dữ Liệu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
