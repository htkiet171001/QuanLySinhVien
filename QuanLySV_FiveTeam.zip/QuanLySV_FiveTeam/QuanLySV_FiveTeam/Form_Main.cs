﻿using DevComponents.DotNetBar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }
        private Form currentFormChinh;
        private void OpenFormChinh(Form formChinh)
        {
            if (currentFormChinh != null)
            {
                currentFormChinh.Close();
            }
            currentFormChinh = formChinh;
            formChinh.TopLevel = false;
            formChinh.Dock = DockStyle.Fill;
            panel3.Controls.Add(formChinh);
            panel3.Tag = formChinh;
            formChinh.BringToFront();
            formChinh.Show();
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFormChinh(new QuanLyHoSoSV());
            labell.Text = button2.Text;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFormChinh(new QuanLyDSLop());
            labell.Text = button5.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (currentFormChinh != null)
            {
                currentFormChinh.Close();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
