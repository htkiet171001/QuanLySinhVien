﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace QuanLySV_FiveTeam
{
   public class KSsv
    {
        public static List<SinhVien.SinhVien> ListSV = new List<SinhVien.SinhVien>();
        public static string pathfile = string.Format(@"{0}\Sinhvien.ini", Application.StartupPath);
        public void GetNguoi(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string line = string.Empty;
                    ListSV.Clear();
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            string[] svarray = line.Split(',');
                            SinhVien.SinhVien sv = new SinhVien.SinhVien();
                            sv.Id = Convert.ToInt64(svarray[0]);
                            sv.Ten = svarray[1];
                            sv.Ngaysinh = svarray[2];
                            sv.Gioitinh = svarray[3];
                            sv.Lop = svarray[4];
                            sv.Diachi = svarray[5];
                            ListSV.Add(sv);

                        }
                    }
                }
            }
        }
    }
}
