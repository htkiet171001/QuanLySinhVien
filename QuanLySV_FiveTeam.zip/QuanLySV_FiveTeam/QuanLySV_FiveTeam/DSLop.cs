﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    class DSLop
    {
        public static List<Lop.Lop> ListDSL = new List<Lop.Lop>();
        public static string pathfile = string.Format(@"{0}\DsLop.ini", Application.StartupPath);
        public void GetLop(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string line = string.Empty;
                    ListDSL.Clear();
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            string[] svarray = line.Split(',');
                            Lop.Lop lp = new Lop.Lop();
                            lp.Stt = Convert.ToInt64(svarray[0]);
                            lp.Khoahoc = svarray[1];
                            lp.Lopp = svarray[2];
                            lp.Gvcn = svarray[3];
                            lp.Khoa = svarray[4];
                            lp.Soluong = svarray[5];
                            ListDSL.Add(lp);

                        }
                    }
                }
            }
        }
    }
}
