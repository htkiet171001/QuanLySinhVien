﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    class DSLop
    {
        public static List<Lop.Lop> ListDSL = new List<Lop.Lop>();//Khoi tao 1 cai list de luu tru du lieu
        public static string pathfile = string.Format(@"{0}\DsLop.ini", Application.StartupPath);//Dua du lieu tu file text vao
        public void GetLop(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.Read))//Doc va lay thong tin tu file text 
            {
                using (StreamReader sr = new StreamReader(fs))//Doc file
                {
                    string line = string.Empty;
                    ListDSL.Clear();
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))//Kiem tra doi tuong hien thi
                        {
                            string[] svarray = line.Split(',');
                            Lop.Lop lp = new Lop.Lop();
                            lp.Stt = Convert.ToInt64(svarray[0]);
                            lp.Khoahoc = svarray[1];
                            lp.Lopp = svarray[2];
                            lp.Gvcn = svarray[3];
                            lp.Khoa = svarray[4];
                            lp.Soluong = svarray[5];
                            ListDSL.Add(lp);

                        }
                    }
                }
            }
        }
    }
}
