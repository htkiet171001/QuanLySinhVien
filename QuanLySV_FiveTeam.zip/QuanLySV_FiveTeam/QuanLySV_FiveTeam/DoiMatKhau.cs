﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    public partial class DoiMatKhau : Form
    {
        public DoiMatKhau()
        {
            InitializeComponent();
        }
        Userlist usl;
        private void Hienthi()
        {
            usl.GetUser(Userlist.pathfile);
            BindingSource bin = new BindingSource();
            bin.DataSource = Userlist.ListUser;
        }
        public void GhiFile(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    foreach (User.Usercf item in Userlist.ListUser)
                    {
                        sw.WriteLine(string.Format("{0},{1},{2}",
                            item.Id, item.Username, item.Pass));
                    }
                }
            }
        }
        private void label6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_DoiMK_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTaiKhoan.Text))
            {
                foreach (User.Usercf item in Userlist.ListUser)
                {
                    if (txtTaiKhoan.Text == item.Username && txtMatKhau2.Text == item.Pass)
                    {
                        if (txtMatKhau1.Text == txtMatKhau2.Text)
                        {
                            item.Id = item.Id;
                            item.Username = txtTaiKhoan.Text;
                            item.Pass = txtMatKhau1.Text;
                            GhiFile(Userlist.pathfile);
                            txtTaiKhoan.Text = "";
                            txtMatKhau1.Text = "";
                            txtMatKhau2.Text = "";
                            Userlist userl = new Userlist();
                            userl.GetUser(Userlist.pathfile);
                            MessageBox.Show("Đổi mật khẩu thành công!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
                MessageBox.Show("Nhập Sai Dữ Liệu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("Nhập thiếu dữ liệu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DoiMatKhau_Load(object sender, EventArgs e)
        {

        }
    }
}

