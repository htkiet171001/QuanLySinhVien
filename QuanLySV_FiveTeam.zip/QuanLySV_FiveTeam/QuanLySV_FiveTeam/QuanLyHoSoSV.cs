﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    public partial class QuanLyHoSoSV : Form
    {
        public QuanLyHoSoSV()
        {
            InitializeComponent();
        }
        int index;
        public delegate void _dongTap();
        public _dongTap DongTap;
        KSsv ks;
        public Form_Main frm;
        public void GhiFile(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    foreach (SinhVien.SinhVien item in KSsv.ListSV)
                    {
                        sw.WriteLine(string.Format("{0},{1},{2},{3},{4},{5}",
                            item.Id, item.Ten, item.Ngaysinh, item.Gioitinh,item.Lop, item.Diachi));
                    }
                }
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataGridViewRow newdata = dgvData.Rows[index];
            newdata.Cells[0].Value = txtMaSV.Text;
            newdata.Cells[1].Value = txtTenSV.Text;
            newdata.Cells[2].Value = txtNgaySinh.Text;
            newdata.Cells[3].Value = txtGioiTinh.Text;
            newdata.Cells[4].Value = txtLop.Text;
            newdata.Cells[5].Value = txtDiachi.Text;
            MessageBox.Show("Sửa và Update Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTenSV.Text))
            {
                SinhVien.SinhVien sinhvien = new SinhVien.SinhVien();
                long max = KSsv.ListSV[0].Id;
                for (int i = 0; i < KSsv.ListSV.Count; i++)
                {
                    if (max < KSsv.ListSV[i].Id)
                    {
                        max = KSsv.ListSV[i].Id;
                    }
                }
                sinhvien.Id = Convert.ToInt64(txtMaSV.Text);
                sinhvien.Ten = txtTenSV.Text;
                sinhvien.Ngaysinh = txtNgaySinh.Text;
                sinhvien.Gioitinh = txtGioiTinh.Text;
                sinhvien.Lop = txtLop.Text;
                sinhvien.Diachi = txtDiachi.Text;
                KSsv.ListSV.Add(sinhvien);
                GhiFile(KSsv.pathfile);
                Hienthi();
                MessageBox.Show("Thêm Sinh Viên Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                MessageBox.Show("Thiếu Dữ Liệu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (sinhVien != null)
            //{
            //    foreach (SinhVien.SinhVien item in KSsv.ListSV)
            //    {
            //        if (item.Id == sinhVien.Id)
            //        {
            //            KSsv.ListSV.Remove(item);
            //            return;
            //        }
            //    }
            //    sinhVien = null;
            //    GhiFile(KSsv.pathfile);
            //    Hienthi();
            //    long max = KSsv.ListSV[0].Id;
            //    for (int i = 0; i < KSsv.ListSV.Count; i++)
            //    {
            //        if (max < KSsv.ListSV[i].Id)
            //        {
            //            max = KSsv.ListSV[i].Id;
            //        }
            //    }
            //    txtMaSV.Text = (max + 1).ToString();
                index = dgvData.CurrentCell.RowIndex;
                dgvData.Rows.RemoveAt(index);
                MessageBox.Show("Xóa Sinh Viên Thành Công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        private void QuanLyHoSoSV_Load(object sender, EventArgs e)
        {
            ks = new KSsv();
            Hienthi();
        }
        private void Hienthi()
        {
            ks.GetNguoi(KSsv.pathfile);
            BindingSource bin = new BindingSource();
            bin.DataSource = KSsv.ListSV;
            dgvData.DataSource = bin;
        }

        SinhVien.SinhVien sinhVien;
        private void dgvData_Click(object sender, EventArgs e)
        {
            if (dgvData.RowCount > 0)
            {
                sinhVien = new SinhVien.SinhVien()
                {
                    Id = Convert.ToInt64(dgvData.CurrentRow.Cells["col_MaSV"].Value.ToString()),
                    Ten = dgvData.CurrentRow.Cells["col_TenSV"].Value.ToString(),
                    Ngaysinh = dgvData.CurrentRow.Cells["col_Ngaysinh"].Value.ToString(),
                    Gioitinh = dgvData.CurrentRow.Cells["col_Gioitinh"].Value.ToString(),
                    Lop = dgvData.CurrentRow.Cells["col_Lop"].Value.ToString(),
                    Diachi = dgvData.CurrentRow.Cells["col_Diachi"].Value.ToString(),
                };
                txtMaSV.Text = dgvData.CurrentRow.Cells["col_MaSV"].Value.ToString();
                txtTenSV.Text = dgvData.CurrentRow.Cells["col_TenSV"].Value.ToString();
                txtNgaySinh.Text = dgvData.CurrentRow.Cells["col_Ngaysinh"].Value.ToString();
                txtGioiTinh.Text = dgvData.CurrentRow.Cells["col_Gioitinh"].Value.ToString();
                txtLop.Text = dgvData.CurrentRow.Cells["col_Lop"].Value.ToString();
                txtDiachi.Text = dgvData.CurrentRow.Cells["col_Diachi"].Value.ToString();
                
                
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
                if (e.RowIndex >= 0)
                {
                //Lưu lại dòng dữ liệu vừa kích chọn
                DataGridViewRow row = this.dgvData.Rows[e.RowIndex];
                //Đưa dữ liệu vào textbox
                txtMaSV.Text = row.Cells[0].Value.ToString();
                txtTenSV.Text = row.Cells[1].Value.ToString();
                txtNgaySinh.Text = row.Cells[2].Value.ToString();
                txtGioiTinh.Text = row.Cells[3].Value.ToString();
                txtLop.Text = row.Cells[4].Value.ToString();
                txtDiachi.Text = row.Cells[5].Value.ToString();

                //Không cho phép sửa trường MaSV
                
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
                //(dgvData.DataSource as DataTable).DefaultView.RowFilter =
                //    String.Format("col_TenSV like '%" + boxtim.Text + "%'");
            long a = Convert.ToInt64(boxtim.Text);
            int b = 0;
            dgvData.ClearSelection();
            foreach (SinhVien.SinhVien per in KSsv.ListSV)
            {
                if (a == per.Id)
                {
                    dgvData.Rows[b].Selected = true;
                    dgvData.FirstDisplayedScrollingRowIndex = b;
                    b = 0;
                    return;
                }
                b++;
            }
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
