﻿namespace SinhVien
{
    public class SinhVien
    {
        private long id;
        private string ten;
        private string ngaysinh;
        private string gioitinh;
        private string lop;
        private string diachi;

        public SinhVien() { }

        public SinhVien(long id, string ten, string ngaysinh, string gioitinh,string lop,string diachi)
        {
            this.Id = id;
            this.Ten = ten;
            this.Ngaysinh = ngaysinh;
            this.Gioitinh = gioitinh;
            this.Lop = lop;
            this.Diachi = diachi;
        }

        public long Id { get => id; set => id = value; }
        public string Ten { get => ten; set => ten = value; }
        public string Ngaysinh { get => ngaysinh; set => ngaysinh = value; }
        public string Gioitinh { get => gioitinh; set => gioitinh = value; }
        public string Lop { get => lop; set => lop = value; }
        public string Diachi { get => diachi; set => diachi = value; }
    }
}
