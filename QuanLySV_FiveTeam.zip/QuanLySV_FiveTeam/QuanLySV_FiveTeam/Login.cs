﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySV_FiveTeam
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        Userlist userl = new Userlist();
        private void Login_Load(object sender, EventArgs e)
        {
            userl.GetUser(Userlist.pathfile);
        }
        public void GhiFile(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    foreach (User.Usercf item in Userlist.ListUser)
                    {
                        sw.WriteLine(string.Format("{0},{1},{2},{3}",
                            item.Id, item.Username, item.Pass));
                    }
                }
            }
        }
        User.Usercf uscf;
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void txtUserName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                errorProvider1.SetError(txtUserName, "Chưa nhập UserName!");
                txtUserName.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void txtPassWord_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassWord.Text))
            {

                if (string.IsNullOrEmpty(txtPassWord.Text))
                {
                    errorProvider1.SetError(txtPassWord, "Chưa nhập PassWord!");
                    txtPassWord.Focus();
                }
                else
                {
                    errorProvider1.Clear();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == "" || txtPassWord.Text == "")
            {
                MessageBox.Show("nhập tên người dùng và mật khẩu");
            }
            else
            {
                        if (txtUserName.Text == "Admin" && txtPassWord.Text == "Admin")
                        {
                            {
                                MessageBox.Show("Đăng nhập thành Công");
                            }
                            Form_Main fm = new Form_Main();
                            fm.Show();
                            this.Hide();
                        }
            }
                    }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DoiMatKhau dmk = new DoiMatKhau();
            dmk.Show();
        }

        private void txtPassWord_TextChanged(object sender, EventArgs e)
        {
            this.txtPassWord.PasswordChar = '*';
        }
    }
}
